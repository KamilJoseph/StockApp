from django.shortcuts import render
from datetime import datetime
import tensorflow as tf
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.models import Sequential
from sklearn.preprocessing import MinMaxScaler
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import yfinance as yf
# Integration Testing 
#-------------------------------------------------------------------------------------------------------------------------------------|
# Test Id  |# Test Case Objective       |  # Test Case Description            | # Expected Results         | Actual results           |
#----------|----------------------------|-------------------------------------|----------------------------|--------------------------|
# 1        | Check if data is able      |  To download historical data        | Stock data is downloaded   | Is able to download data |
#          | to download.               |  using Yahoo finance                |                            |                          |
#          |----------------------------|-------------------------------------|----------------------------|--------------------------|
# 2        |Rendering index.html        | Rendering HTML page to display      | Should be able to display  | Displays content on HTML |      
#          |                            | graphs and charts onto the template | graphs and chart           | page.                    |
#          |----------------------------|-------------------------------------|----------------------------|--------------------------|
# 3        |Display Candle Stick Chart  | Ensure that candlestick chart gather| Displaying candlestick     | Candlstick chart is      |
#          |                            |  and display stock data             | data                       | displayed and interactive|
#          |----------------------------|-------------------------------------|----------------------------|--------------------------|
# 4        |Create LSTM model           | To ensure that model works and is   | Model works and trains the |LSTM model is able to     |
#          |                            |  efficent                           | data                       |train the data            |
#          |----------------------------|-------------------------------------|----------------------------|--------------------------|
# 5        |Display plotly graph        | Displaying actual price to predicted| Plotly is able to display  | Plotly is able to        |
#          |                            | price on plotly                     | and compare actual data to | compare predicted data to|
#          |                            |                                     | predicted data             | actual data.             |
#======================================================================================================================================
def download_stock_data(stock_symbol, start_date, end_date):
    df = yf.download(stock_symbol, start=start_date, end=end_date)
    if df.empty:
        raise ValueError("No data fetched. Check stock symbol and date range.")
    return df

def preprocess_data(df):
    if df.empty:
        raise ValueError("Dataframe is empty. Check stock symbol and date range.")
    df1 = df[['Adj Close']].values.reshape(-1, 1)
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(df1)
    return scaled_data, scaler, df

        # The dataset is a numpy array containing the time series data.
        # time_step denotes the number of prior steps used for prediction, which is set to 15.
def create_dataset(dataset, time_step=15):
        # Generate empty lists to retain the input sequences (X) and matching target values (y).
    X, y = [], []
        # Loop through the dataset to generate sequences.
        # The loop iterates from the dataset's start to its length, minus the time_step, then repeats to ensure  predictions.
    for i in range(len(dataset) - time_step - 1):
        # a  variable is a sequence of time_step length starting from the dataset at index 'i'.
        a = dataset[i:(i + time_step), 0]
        X.append(a)
        # The target value to predict is the value immediately after the present sequence.              
        b = dataset[i + time_step, 0]
        y.append(b)
        # Convert the lists of input sequences and target values to numpy arrays
    return np.array(X), np.array(y)


def create_stacked_lstm_model(input_shape):
    model = Sequential()
    model.add(LSTM(50, input_shape=input_shape, return_sequences=True))
    model.add(Dropout(0.2))
    model.add(LSTM(50, return_sequences=True))
    model.add(Dropout(0.2))
    model.add(LSTM(50))
    model.add(Dropout(0.2))
    model.add(Dense(1))
    model.compile(loss='mean_squared_error', optimizer='adam')
    return model

def index(request):
    if request.method == 'POST':
        stock_symbol = request.POST.get('stock_symbol')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        end_date = datetime.strptime(end_date, '%Y-%m-%d')

        # Download stock data
        df = download_stock_data(stock_symbol, start_date, end_date)

        if df is None or df.empty:
            return render(request, 'index.html', {'error': 'Failed to download stock data'})

        # Preprocess the data
        scaled_data, scaler, df = preprocess_data(df)

        time_step = 15
        
        # Split the data into training, validation, and test sets
        train_size = int(len(scaled_data) * 0.7)
        val_size = int(len(scaled_data) * 0.15)
        test_size = int(len(scaled_data) * 0.15)

        train = scaled_data[0:train_size, :]
        val = scaled_data[train_size:train_size + val_size, :]
        test = scaled_data[train_size + val_size:len(scaled_data), :]

   
   
        # Retrieve all the data from the dataframe
        # Take the value of 15 (time_step) and create sequences of data
        # a = dataset[i:(i + time_step), 0] - This line takes a sequence of 15 values from the dataset starting at index i
        # X.append(a) - This line appends the sequence to the X list
        # y.append(dataset[i + time_step, 0]) - This line appends the next value in the sequence (the value we want to predict) to the y list
        # This process creates the input-output pairs used to train the mode
        x_train, y_train = create_dataset(train, time_step)
        x_val, y_val = create_dataset(val, time_step)
        x_test, y_test = create_dataset(test, time_step)

        x_train = np.reshape(x_train, (x_train.shape[0], time_step, 1))
        x_val = np.reshape(x_val, (x_val.shape[0], time_step, 1))
        x_test = np.reshape(x_test, (x_test.shape[0], time_step, 1))

      
        # Create the LSTM model
        model = create_stacked_lstm_model((time_step, 1))
        model.summary()
        
        # Train the model, including validation data for monitoring validation loss
        model.fit(x_train, y_train, validation_data=(x_val, y_val), epochs=10, batch_size=32, verbose=2)


        # Make predictions on the test data
        testPredict = model.predict(x_test)
        
        # Invert the predictions and actual test values to the original scale
        testPredict = scaler.inverse_transform(testPredict)
        testY = scaler.inverse_transform([y_test])

        # Create a date range for the predictions
        prediction_dates = df.index[-len(testPredict):]

        # Plot the actual prices and the predicted prices using Plotly
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=df.index,
            y=scaler.inverse_transform(scaled_data).flatten(),
            mode='lines',
            name='Actual Price'
        ))
        fig.add_trace(go.Scatter(
            x=prediction_dates,
            y=testPredict.flatten(),
            mode='lines',
            name='Test Predictions'
        ))

        graph_div = fig.to_html(full_html=False)

        # Prepare candlestick and volume data for visualization
        candlestick_data = prepare_candlestick_data(df)
        volume_data = prepare_volume_data(df)

        context = {
            'data': df.head(10),
            'graph_div': graph_div,
            'candlestick_data': candlestick_data,
            'volume_data': volume_data,
        }

        # Render the index template with the context
        return render(request, 'index.html', context)
    
    # Render the index template for GET requests
    return render(request, 'index.html')


def prepare_candlestick_data(df):
    candlestick_data = []
    for index, row in df.iterrows():
        # Converts the timestamp to millieseconds 
        x = int(index.timestamp() * 1000)
        y = [row["Open"], row["High"], row["Low"], row["Close"], row["Adj Close"]]
        candlestick_data.append({"x": x, "y": y})
    return candlestick_data

def prepare_volume_data(df):
    volume_data = []
    for index, row in df.iterrows():
        x = int(index.timestamp() * 1000)
        y = row["Volume"]
        volume_data.append({"x": x, "y": y})
    return volume_data

# Ritesh. (n.d.). Develop LSTM models for time series forecasting. Kaggle. Retrieved June 11, 2024, from https://www.kaggle.com/code/ritesh7355/develop-lstm-models-for-time-series-forecasting

# Amin, H. (n.d.). Time series analysis using LSTM Keras. Kaggle. Retrieved June 11, 2024, from https://www.kaggle.com/code/hassanamin/time-series-analysis-using-lstm-keras