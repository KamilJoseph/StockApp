// Allows extensions or specific libraries to gather all stock data from Yahoo Finance API
// addEventListener (type, listener)
// refer to: https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener 
// Apex charts: https://apexcharts.com/javascript-chart-demos/candlestick-charts/ 

// DOM content needs to be loaded before running the Javascript
document.addEventListener('DOMContentLoaded', function() 
{
    // Check if the variables 'candlestick_data' and 'volume_data' are defined
    if (typeof candlestick_data !== 'undefined' && typeof volume_data !== 'undefined')
        {
        // Define options for the candlestick chart
        var candlestickOptions = {
            series: [{
                data: candlestick_data // Data for the candlestick chart
            }],
            chart: {
                type: 'candlestick', // Type of chart
                height: 290, // Height of the chart
                id: 'candles', // Unique identifier for the chart
                toolbar: {
                    autoSelected: 'pan', // Default toolbar option
                    show: false // Hide the toolbar
                },
                zoom: {
                    enabled: false // Disable zooming
                },
                background: '#000000' // Black background color
            },
            plotOptions: {
                candlestick: {
                    colors: {
                        upward: '#4CAF50', // Green for upward candles
                        downward: '#F44336' // Red for downward candles
                    }
                }
            },
            xaxis: {
                type: 'datetime', // X-axis represents datetime
                labels: {
                    style: {
                        colors: '#FFFFFF' // White color for x-axis labels
                    }
                }
            },
            yaxis: {
                labels: {
                    style: {
                        colors: '#FFFFFF' // White color for y-axis labels
                    }
                }
            }
        };

        // Initialize and render the candlestick chart
        var candlestickChart = new ApexCharts(document.querySelector("#chart-candlestick"), candlestickOptions);
        candlestickChart.render();

        // Define options for the bar chart
        var barOptions = {
            series: [{
                name: 'volume', // Name of the series
                data: volume_data // Data for the bar chart
            }],
            chart: {
                height: 160, // Height of the chart
                type: 'bar', // Type of chart
                brush: {
                    enabled: true, // Enable brush
                    target: 'candles' // Link brush to the candlestick chart
                },
                selection: {
                    enabled: true, // Enable selection
                    xaxis: {
                        min: new Date('20 Jan 2017').getTime(), // Minimum date for selection
                        max: new Date('10 Dec 2017').getTime() // Maximum date for selection
                    },
                    fill: {
                        color: '#FFFFFF', // Fill color for selection
                        opacity: 0.4 // Opacity for selection fill
                    },
                    stroke: {
                        color: '#ffffff', // Stroke color for selection
                    }
                },
                background: '#FFFFFF' // White background color
            },
            dataLabels: {
                enabled: false // Disable data labels
            },
            plotOptions: {
                bar: {
                    columnWidth: '80%', // Width of the bars
                    colors: {
                        ranges: [{
                            from: -1000,
                            to: 0,
                            color: '#FFFFFF' // Light gray for negative bars
                        }, {
                            from: 1,
                            to: 10000,
                            color: '#FFFFFF' // Dark gray for positive bars
                        }],
                    },
                }
            },
            stroke: {
                width: 0 // No stroke width
            },
            xaxis: {
                type: 'datetime', // X-axis represents datetime
                axisBorder: {
                    offsetX: 13, // Offset for x-axis border
                    color: '#ffffff' // White color for x-axis border
                },
                labels: {
                    style: {
                        colors: '#ffffff' // White color for x-axis labels
                    }
                }
            },
            yaxis: {
                labels: {
                    style: {
                        colors: '#FFFFFF' // White color for y-axis labels
                    }
                },
                axisBorder: {
                    color: '#FFFFFF' // White color for y-axis border
                }
            }
        };

        // Initialize and render the bar chart
        var barChart = new ApexCharts(document.querySelector("#chart-bar"), barOptions);
        barChart.render();
    } else {
        // Log an error if 'candlestick_data' or 'volume_data' is undefined
        console.error('candlestick_data or volume_data is undefined');
    }
});
